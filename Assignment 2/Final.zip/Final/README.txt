 I have written all code in python3.

 I have separatly did codes for each question and labeled them as 1a.py, 1b.py, 1.c.py and 2a.py


 and for 3 rd question ID3 algorithm is wriiten differently in ID3.py and DT pruning without pruning code is there differently in 3DT.py


 Sharath Kumar Karnati, #011852253