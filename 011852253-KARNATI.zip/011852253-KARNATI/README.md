# I have used python3 for all the code submitted.

# I have written algorithms in the algorithms.py file 

# I have written code for Graphs plotting in separate file called graphs.py

# I have inplemented code for 5.1 and 5.2 questions in the perceptrongraphs.py file by calling the functions from both algorithms.py and graphs.py.

# Run perceptrongraphs.py to see the graphs submitted. 


Thank You,


SHARATH KUMAR KARNATI.011852253.