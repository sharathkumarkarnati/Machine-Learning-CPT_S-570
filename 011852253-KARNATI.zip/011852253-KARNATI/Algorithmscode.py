import numpy as np

def get_initial_weights(x, mode, existing_weights):
    if mode == "Train":
        return np.zeros(x.shape[1])
    else:
        return existing_weights

def update_weights(method, features, label, current_weights):
    try:
        if method == "Perceptron":
            return current_weights + 1 * label * features
        elif method == "PA":
            tau = (1 - (label * np.dot(current_weights, features))) / (np.dot(features, features))
            return current_weights + tau * label * features
    except:
        return 0

def perceptron_binary_classifier(features, labels, iterations, method, mode, initial_weights):
    weights = get_initial_weights(features, mode, initial_weights)
    learning_stats = []
    mistakes_stats = []
    accuracy_stats = []

    for _ in range(iterations):
        accuracy_count = 0
        learning_count = 0
        for i in range(len(features)):
            prediction = np.sign(np.dot(weights, features[i]))
            if prediction != labels[i]:
                weights = update_weights(method, features[i], labels[i], weights)
                learning_count += 1
            else:
                accuracy_count += 1
        accuracy_stats.append(accuracy_count * 100 / len(features))
        mistakes_stats.append(learning_count)
        learning_stats.append(learning_count)

    return weights, mistakes_stats, learning_stats, accuracy_stats

def binary_general_learning_curve(features, labels, iterations, method, mode, initial_weights, training_lengths):
    weights = get_initial_weights(features, mode, initial_weights)
    learning_stats = []
    mistakes_stats = []
    accuracy_stats = []

    for i in range(iterations):
        accuracy_count = 0
        learning_count = 0

        for j in range(len(features)):
            if j < training_lengths[i]:
                prediction = np.sign(np.dot(weights, features[j]))
                if prediction != labels[j]:
                    learning_count += 1
                    weights = update_weights(method, features[j], labels[j], weights)
                else:
                    accuracy_count += 1
        accuracy_stats.append(accuracy_count * 100 / training_lengths[i])
        learning_stats.append(learning_count)
        mistakes_stats.append(learning_count)

    return weights, mistakes_stats, learning_stats, accuracy_stats

def avg_perceptron(features, labels, iterations, mode, initial_weight):
    weights = get_initial_weights(features, mode, initial_weight)
    learning_stats = []
    u = np.zeros(features.shape[1])
    accuracy_stats = []
    confidence = 1

    for _ in range(iterations):
        accuracy_count = 0

        for i in range(features.shape[0]):
            prediction = np.dot(labels[i], np.dot(weights, features[i]))

            if prediction <= 0:
                weights += labels[i] * features[i]
                u += confidence * labels[i] * features[i]
            else:
                accuracy_count += 1
            confidence += 1

        accuracy_stats.append(accuracy_count * 100 / len(features))
        learning_stats.append(confidence)

    final_weights = weights - (u / confidence)
    return final_weights, learning_stats, accuracy_stats

def update_multiclass_weights(features, label, weights, method_type):
    F = np.zeros(shape=(10, len(features) * 10))
    is_mistake = False

    for i in range(10):
        F[i][i * len(features) : (i + 1) * len(features)] = features
    product = np.zeros(10)

    for i in range(10):
        product[i] = np.dot(weights, F[i])

    prediction = np.where(product == np.amax(product))[0][0]

    if prediction != label:
        is_mistake = True
        if method_type == "Perceptron":
            weights += F[label] - F[prediction]
        elif method_type == "PA":
            denom = np.linalg.norm(F[label] - F[prediction], ord=1) ** 2
            tau = (1 - (np.dot(weights, F[label]) - np.dot(weights, F[prediction]))) / denom
            weights += (F[label] - F[prediction]) * tau
    return weights, is_mistake

def multiclass_classifier(features, labels, iterations, method_type, initial_weights=None):
    if initial_weights is None:
        initial_weights = np.zeros(len(features[0]) * 10)

    mistakes = []

    for step in range(iterations):
        mistake_count = 0
        for i in range(len(features)):
            result = update_multiclass_weights(features[i], labels[i], initial_weights, method_type)
            initial_weights = result[0]
            if result[1]:
                mistake_count += 1
        mistakes.append(mistake_count)

    return initial_weights, mistakes

def test_multiclass_classifier(features, labels, weights):
    correct_classifications = 0
    for i in range(len(features)):
        F = np.zeros(shape=(10, len(features[i]) * 10))

        for j in range(10):
            F[j][j * len(features[i]) : (j + 1) * len(features[i])] = features[i]

        product = np.zeros(10)
        for j in range(10):
            product[j] = np.dot(weights, F[j])

        predicted_class = np.where(product == np.amax(product))[0][0]

        if predicted_class == labels[i]:
            correct_classifications += 1

    return correct_classifications * 100 / len(features)

def update_avg_weights(features, u, count, true_label, weights):
    F = np.zeros(shape=(10, len(features) * 10))
    for i in range(10):
        F[i][i * len(features) : (i + 1) * len(features)] = features
    product = np.zeros(10)

    for i in range(10):
        product[i] = np.dot(weights, F[i])

    prediction = np.where(product == np.amax(product))[0][0]

    if prediction != true_label:
        weights += F[true_label] - F[prediction]
        u += np.dot((F[true_label] - F[prediction]), count + 1)

    return weights, u

def avg_multiclass_classifier(features, labels, iterations, initial_weights):
    for step in range(iterations):
        u = np.zeros(len(features[0]) * 10)

        for i in range(len(features)):
            result = update_avg_weights(features[i], u, i, labels[i], initial_weights)
            initial_weights = result[0]
            u = result[1]

    return initial_weights - (u / len(features)), u

