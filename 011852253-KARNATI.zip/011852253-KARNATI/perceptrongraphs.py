from turtle import color
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time as time
import Algorithmscode as perceptron
import graphs as graph

# Load and prepare data
train_data = pd.read_csv("/Users/sharathkarnati/Desktop/ML/KARNATI-011852253/011852253-KARNATI/fashion-mnist_training-and-testing-data/fashion-mnist_train.csv")
test_data = pd.read_csv("/Users/sharathkarnati/Desktop/ML/KARNATI-011852253/011852253-KARNATI/fashion-mnist_training-and-testing-data/fashion-mnist_test.csv")

X_train = np.array(train_data.iloc[:, 1:785])
Y_train = np.array(train_data.iloc[:, 0])

Y_train = np.array(list(map(lambda x: 1 if (x % 2 == 0) else -1, Y_train)))

X_test = np.array(test_data.iloc[:, 1:785])
Y_test = np.array(test_data.iloc[:, 0])

Y_test = np.array(list(map(lambda x: 1 if (x % 2 == 0) else -1, Y_test)))

# Perceptron algorithm
p_train = perceptron.perceptron_binary_classifier(
    X_train, Y_train, 50, "Perceptron", "Train", 0
)

p_test = perceptron.perceptron_binary_classifier(
    X_test, Y_test, 50, "Perceptron", "Test", p_train[0]
)

pa_train = perceptron.perceptron_binary_classifier(
    X_train, Y_train, 50, "PA", "Train", 0
)

pa_test = perceptron.perceptron_binary_classifier(
    X_test, Y_test, 50, "PA", "Test", pa_train[0]
)

# Plot learning curves
graph.create_line_plot(
    np.arange(0, 50),
    p_train[1],
    "Perceptron Learning Curve",
    "Iterations",
    "Mistakes",
    "Perceptron Learning Curve",
    "../output/5.1a_Perceptron_Learning_Curve.jpeg",
)

graph.create_line_plot(
    np.arange(0, 50),
    pa_train[1],
    "Passive Aggressive Learning Curve",
    "Iterations",
    "Mistakes",
    "Passive Aggressive Learning Curve",
    "../output/5.1a_PA_Learning_Curve.jpeg",
)

graph.create_two_line_plots(
    np.arange(0, 50),
    p_train[1],
    "Perceptron Learning Curve",
    np.arange(0, 50),
    pa_train[1],
    "Passive Aggressive Curve",
    "Iterations",
    "Mistakes",
    "Perceptron V/S Passive Aggressive Curve",
    "../output/5.1a_Perceptron_vs_PA_Comparision.jpeg",
)

graph.create_line_plot(
    np.arange(0, 20),
    p_train[3][0:20],
    "Perceptron algorithm training accuracy",
    "Iterations",
    "Accuracy",
    "Perceptron Algorithm Accuracy : Training",
    "../output/5.1b_Perceptron_Accuracy_training.jpeg",
)

graph.create_line_plot(
    np.arange(0, 20),
    p_test[3][0:20],
    "Perceptron algorithm testing accuracy",
    "Iterations",
    "Accuracy",
    "Perceptron Algorithm Accuracy : Testing",
    "../output/5.1b_Perceptron_Accuracy_testing.jpeg",
)

graph.create_line_plot(
    np.arange(0, 20),
    pa_train[3][0:20],
    "Passive Aggressive algorithm training accuracy",
    "Iterations",
    "Accuracy",
    "Passive Aggressive Algorithm Accuracy : Training",
    "../output/5.1b_passive_aggresive_Accuracy_training.jpeg",
)

graph.create_line_plot(
    np.arange(0, 20),
    pa_test[3][0:20],
    "Passive Aggressive algorithm testing accuracy",
    "Iterations",
    "Accuracy",
    "Passive Aggressive Algorithm Accuracy : Testing",
    "../output/5.1b_passive_aggresive_Accuracy_testing.jpeg",
)

graph.create_two_line_plots(
    np.arange(0, 20),
    p_train[3][0:20],
    "Perceptron algorithm training accuracy",
    np.arange(0, 20),
    pa_train[3][0:20],
    "PA training accuracy",
    "Iterations",
    "Accuracy",
    "Perceptron Algorithm and PA Accuracy : Training",
    "../output/5.1b_Perceptron_and_PA_Accuracy_training.jpeg",
)

graph.create_two_line_plots(
    np.arange(0, 20),
    p_test[3][0:20],
    "Perceptron algorithm testing accuracy",
    np.arange(0, 20),
    pa_test[3][0:20],
    "PA testing accuracy",
    "Iterations",
    "Accuracy",
    "Perceptron Algorithm and PA Accuracy : Testing",
    "../output/5.1b_Perceptron_and_PA_Accuracy_testing.jpeg",
)

# Average Perceptron
avgp_train = perceptron.avg_perceptron(X_train, Y_train, 20, "Train", 0)
avgp_test = perceptron.avg_perceptron(X_test, Y_test, 20, "Test", avgp_train[0])

graph.create_line_plot(
    np.arange(0, 20),
    avgp_train[2],
    "Accuracy of Average Perceptron : Train data",
    "Iteration",
    "Accuracy",
    "Accuracy of Average Perceptron : Train data",
    "../output/5.1c_Average_perceptron_accuracy_training.png",
)

graph.create_line_plot(
    np.arange(0, 20),
    avgp_test[2],
    "Accuracy of Average Perceptron : Test data",
    "Iteration",
    "Accuracy",
    "Accuracy of Average Perceptron : Test data",
    "../output/5.1c_Average_perceptron_accuracy_testing.png",
)

# General Learning Curve
train_examples = [
    100, 200, 300, 400, 500, 600, 700, 800, 900, 1000,
    1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2000,
]

p_train = perceptron.binary_general_learning_curve(X_train, Y_train, 20, "Perceptron", "Train", 0, train_examples)
p_test = perceptron.binary_general_learning_curve(X_test, Y_test, 20, "Perceptron", "Test", p_train[0], train_examples)

pa_train = perceptron.binary_general_learning_curve(X_train, Y_train, 20, "PA", "Train", 0, train_examples)
pa_test = perceptron.binary_general_learning_curve(X_test, Y_test, 20, "PA", "Test", pa_train[0], train_examples)

graph.create_line_plot(
    train_examples,
    p_test[3],
    "Perceptron General Learning Curve : Test data",
    "Training examples",
    "Accuracy",
    "General Learning curve : Test data",
    "../output/5.1d_Perceptron_Gen_learn_curve.png",
)

graph.create_line_plot(
    train_examples,
    pa_test[3],
    "Passive Aggressive General Learning Curve : Test data",
    "Training examples",
    "Accuracy",
    "General Learning curve : Test data",
    "../output/5.1d_PA_Gen_learn_curve.png",
)

# Multi-class Classification
Y_train = np.array(train_data.iloc[:, 0])
Y_test = np.array(test_data.iloc[:, 0])

multi_p_train = perceptron.multiclass_classifier(X_train, Y_train, 50, "Perceptron")
multi_pa_train = perceptron.multiclass_classifier(X_train, Y_train, 50, "PA")

graph.create_two_line_plots(
    np.arange(0, 50),
    multi_p_train[1],
    "Multi class Perceptron",
    np.arange(0, 50),
    multi_pa_train[1],
    "Multi class Passive Aggressive",
    "Iterations",
    "Mistakes",
    "Multi class classifier - Iterations vs Mistakes",
    "../output/5.2a_multiclass_classifier_graph.png",
)

# Multi-class Accuracy
multi_p_train_accuracy = []
multi_p_test_accuracy = []
multi_pa_train_accuracy = []
multi_pa_test_accuracy = []

multi_p_weight = [0] * (len(X_train[0]) * 10)
multi_pa_weight = [0] * (len(X_train[0]) * 10)

for i in range(20):
    w = perceptron.multiclass_classifier(X_train, Y_train, 1, "Perceptron", multi_p_weight)
    multi_p_weight = w[0]
    multi_p_train_accuracy.append(perceptron.test_multiclass_classifier(X_train, Y_train, w[0]))
    multi_p_test_accuracy.append(perceptron.test_multiclass_classifier(X_test, Y_test, w[0]))

    w = perceptron.multiclass_classifier(X_train, Y_train, 1, "PA", multi_pa_weight)
    multi_pa_weight = w[0]
    multi_pa_train_accuracy.append(perceptron.test_multiclass_classifier(X_train, Y_train, w[0]))
    multi_pa_test_accuracy.append(perceptron.test_multiclass_classifier(X_test, Y_test, w[0]))

graph.create_two_line_plots(
    np.arange(0, 20),
    multi_p_train_accuracy,
    "Perceptron Multi class : Training",
    np.arange(0, 20),
    multi_p_test_accuracy,
    "Perceptron Multi class : Testing",
    "Iterations",
    "Accuracy",
    "Perceptron multiclass Accuracy train vs test",
    "../output/5.2b_Multi_class_perceptron_accuracy.png",
)

graph.create_two_line_plots(
    np.arange(0, 20),
    multi_pa_train_accuracy,
    "Passive Aggressive Multi class : Training",
    np.arange(0, 20),
    multi_pa_test_accuracy,
    "Passive Aggressive Multi class : Testing",
    "Iterations",
    "Accuracy",
    "Passive Aggressive multiclass Accuracy train vs test",
    "../output/5.2b_Multi_class_passive_aggressive_accuracy.png",
)

# Average Multi-class Perceptron
multi_avg_train_accuracy = []
multi_avg_test_accuracy = []

multi_avg_weight = np.zeros(len(X_train[0]) * 10)

for i in range(20):
    trained_weight = perceptron.avg_multiclass_classifier(X_train, Y_train, 1, multi_avg_weight)
    multi_avg_weight = trained_weight[0]

    multi_avg_train_accuracy.append(perceptron.test_multiclass_classifier(X_train, Y_train, multi_avg_weight))
    multi_avg_test_accuracy.append(perceptron.test_multiclass_classifier(X_test, Y_test, multi_avg_weight))

graph.create_two_line_plots(
    np.arange(0, 20),
    multi_p_test_accuracy,
    "Perceptron Multi class accuracy",
    np.arange(0, 20),
    multi_avg_test_accuracy,
    "Averaged Perceptron Multi class Accuracy",
    "Iterations",
    "Accuracy",
    "Perceptron vs Averaged Perceptron Testing Accuracy",
    "../output/5.2c_Perceptron_vs_avg_test_accuracy.png",
)

# Sample Size vs Accuracy
train_data_size = 100
samples = [i for i in range(500, 60001, 500)]
accuracy = []

for i in range(20):
    train_data_indices = np.random.choice(len(train_data), size=train_data_size, replace=False)
    train_data_sample = train_data.filter(train_data_indices, axis=0)
    X_train = np.array(train_data_sample.iloc[:, 1:785])
    Y_train = np.array(train_data_sample.iloc[:, 0])
    weight = perceptron.multiclass_classifier(X_train, Y_train, 1, "Perceptron")
    accuracy.append(perceptron.test_multiclass_classifier(X_test, Y_test, weight[0]))
    train_data_size += 100

graph.create_line_plot(
    samples[0:20],
    accuracy,
    "Sample size vs Accuracy",
    "Size",
    "Accuracy",
    "Sample size vs Accuracy",
    "../output/5.2d_gen_learn_accuracy.png",
)
