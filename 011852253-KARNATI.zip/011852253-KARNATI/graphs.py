import matplotlib.pyplot as plt

def create_line_plot(x_values, y_values, plot_label, x_axis_label, y_axis_label, plot_title, save_as_file):
    plt.plot(x_values, y_values, label=plot_label)
    plt.xlabel(x_axis_label)
    plt.ylabel(y_axis_label)
    plt.title(plot_title)
    plt.legend()
    # plt.savefig(save_as_file)
    plt.show()
    plt.close()

def create_two_line_plots(
    x_values1,
    y_values1,
    plot_label1,
    x_values2,
    y_values2,
    plot_label2,
    x_axis_label,
    y_axis_label,
    plot_title,
    save_as_file
):
    plt.plot(x_values1, y_values1, label=plot_label1)
    plt.plot(x_values2, y_values2, label=plot_label2)
    plt.xlabel(x_axis_label)
    plt.ylabel(y_axis_label)
    plt.title(plot_title)
    plt.legend()
    # plt.savefig(save_as_file)
    plt.show()
    plt.close()
